
# Copyright (c) 2026 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl
module "certmanager" {
  count = alltrue([
    anytrue([
      var.preferred_kubernetes_services == "public",
      var.install_kueue,
      var.install_nvidia_dra_driver,
      alltrue([var.install_monitoring, var.install_node_problem_detector_kube_prometheus_stack]),
      local.slinky_cert_manager_required,
    ]),
    local.deploy_from_operator
  ]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name     = "cert-manager"
  helm_chart_name     = "cert-manager"
  namespace           = "cert-manager"
  helm_repository_url = "oci://quay.io/jetstack/charts"
  helm_chart_version  = var.cert_manager_chart_version

  pre_deployment_commands = [
    "export PATH=$PATH:/home/${local.operator_user}/bin",
    "export OCI_CLI_AUTH=instance_principal",
    "export PYTHONWARNINGS=\"ignore:the 'strict' parameter::urllib3.poolmanager\"",
    "grep -q 'parameter::urllib3.poolmanager' ~/.bashrc || cat >> ~/.bashrc <<'EOF'\nexport PYTHONWARNINGS=\"ignore:the 'strict' parameter::urllib3.poolmanager\"\nEOF",
  ]

  post_deployment_commands = [
    join("\n", [
      "probe_apply_success=false",
      "for i in $(seq 1 30); do",
      "  if cat <<'EOF' | kubectl apply -f -; then",
      file("${path.module}/files/cert-manager/webhook-readiness-probe.yaml"),
      "EOF",
      "    probe_apply_success=true",
      "    break",
      "  fi",
      "  echo \"cert-manager webhook probe apply failed ($i/30), retrying in 2s...\"",
      "  sleep 10",
      "done",
      "if [ \"$probe_apply_success\" != \"true\" ]; then",
      "  echo \"ERROR: failed to apply cert-manager webhook probe after 30 attempts\"",
      "  exit 1",
      "fi",
    ])
  ]

  deployment_extra_args = ["--force", "--dependency-update", "--history-max 1", "--wait"]

  helm_template_values_override = file("${path.module}/files/cert-manager/values.yaml")
  helm_user_values_override     = ""

  depends_on = [module.oke]
}

module "ingress" {
  count  = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack, var.install_grafana, var.preferred_kubernetes_services == "public"]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name     = "contour"
  helm_chart_name     = "contour"
  namespace           = "projectcontour"
  helm_repository_url = "https://projectcontour.github.io/helm-charts/"
  helm_chart_version  = var.ingress_chart_version

  pre_deployment_commands = [
    "export PATH=$PATH:/home/${local.operator_user}/bin",
    "export OCI_CLI_AUTH=instance_principal"
  ]
  post_deployment_commands = flatten([
    "cat <<'EOF' | kubectl apply -f -",
    (var.use_lets_encrypt_prod_endpoint == true ?
      split("\n", templatefile("${path.module}/files/cert-manager/cluster-issuer-prod.yaml", { state = local.state_id })) :
      split("\n", templatefile("${path.module}/files/cert-manager/cluster-issuer-staging.yaml", { state = local.state_id }))
    ),
    "EOF",
    "sleep 60" #wait for the LB to be provisioned
  ])
  deployment_extra_args = ["--wait"]

  helm_template_values_override = templatefile(
    "${path.module}/files/ingress/values.yaml.tpl",
    {
      min_bw    = 10,
      max_bw    = 100,
      lb_nsg_id = module.oke.pub_lb_nsg_id,
      state_id  = local.state_id
    }
  )
  helm_user_values_override = ""

  depends_on = [module.oke, module.certmanager]
}


module "kube_prometheus_stack" {
  count  = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name     = "kube-prometheus-stack"
  helm_chart_name     = "kube-prometheus-stack"
  namespace           = var.monitoring_namespace
  helm_repository_url = "https://prometheus-community.github.io/helm-charts"
  helm_chart_version  = var.prometheus_stack_chart_version

  pre_deployment_commands = flatten([
    [
      "export PATH=$PATH:/home/${local.operator_user}/bin",
      "export OCI_CLI_AUTH=instance_principal",
    ],
    var.install_grafana && var.preferred_kubernetes_services == "public" ? [
      "command -v jq >/dev/null 2>&1 || sudo bash -c 'apt-get update && apt-get install -y jq || yum install -y jq || dnf install -y jq'",
      "export INGRESS_IP=$(kubectl get svc -A -l app.kubernetes.io/name=contour  -o json | jq -r '.items[] | select(.spec.type == \"LoadBalancer\") | .status.loadBalancer.ingress[].ip')"
    ] : []
  ])

  deployment_extra_args = flatten([
    [
      "--force",
      "--dependency-update",
      "--history-max 1",
      "--wait",
    ],
    var.install_grafana ? (var.preferred_kubernetes_services == "public" ? [
      "--set grafana.ingress.enabled=true",
      "--set grafana.ingress.ingressClassName=contour",
      "--set-string grafana.ingress.annotations.'cert-manager\\.io\\/cluster-issuer'=le-clusterissuer",
      "--set-string grafana.ingress.annotations.'ingress\\.kubernetes\\.io/force-ssl-redirect'=true",
      "--set grafana.ingress.hosts[0]=grafana.$${INGRESS_IP}.${var.wildcard_dns_domain}",
      "--set grafana.ingress.tls[0].hosts[0]=grafana.$${INGRESS_IP}.${var.wildcard_dns_domain}",
      "--set grafana.ingress.tls[0].secretName=grafana-tls"
      ] :
      [
        "--set grafana.service.type=LoadBalancer",
        "--set-string grafana.service.annotations.'oci\\.oraclecloud\\.com\\/load-balancer-type'=lb",
        "--set-string grafana.service.annotations.'service\\.beta\\.kubernetes\\.io\\/oci-load-balancer-internal'=true",
        "--set-string grafana.service.annotations.'service\\.beta\\.kubernetes\\.io\\/oci-load-balancer-shape'=flexible",
        "--set-string grafana.service.annotations.'service\\.beta\\.kubernetes\\.io\\/oci-load-balancer-shape-flex-min'=100",
        "--set-string grafana.service.annotations.'service\\.beta\\.kubernetes\\.io\\/oci-load-balancer-shape-flex-max'=100",
        "--set-string grafana.service.annotations.'service\\.beta\\.kubernetes\\.io\\/oci-load-balancer-security-list-management-mode'=None",
        format("--set-string grafana.service.annotations.'oci\\.oraclecloud\\.com\\/oci-network-security-groups'=%s", module.oke.int_lb_nsg_id)
    ]) : []
  ])

  post_deployment_commands = []

  helm_template_values_override = templatefile("${path.module}/files/kube-prometheus/values.yaml.tftpl", {
    install_grafana               = var.install_grafana
    preferred_kubernetes_services = var.preferred_kubernetes_services
    setup_alerting                = var.setup_alerting
  })

  helm_user_values_override = var.install_grafana ? yamlencode(
    {
      grafana = merge(
        {
          adminPassword = random_password.grafana_admin_password[0].result
        },
        var.preferred_kubernetes_services == "internal" ?
        {
          service = {
            annotations = {
              "oci.oraclecloud.com/initial-freeform-tags-override" : jsonencode({ "state_id" = local.state_id, "application" : "grafana" })
            }
          }
      } : {})
    }
  ) : ""
  depends_on = [module.ingress]
}


module "node_problem_detector_amd" {
  count  = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack, local.has_amd_gpu]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name     = "gpu-rdma-node-problem-detector-amd"
  helm_chart_name     = "node-problem-detector"
  namespace           = var.monitoring_namespace
  helm_repository_url = "oci://ghcr.io/deliveryhero/helm-charts"
  helm_chart_version  = var.node_problem_detector_chart_version

  pre_deployment_commands = [
    "export PATH=$PATH:/home/${local.operator_user}/bin",
    "export OCI_CLI_AUTH=instance_principal"
  ]
  deployment_extra_args    = ["--force", "--dependency-update", "--history-max 1"]
  post_deployment_commands = []

  helm_template_values_override = file("${path.module}/files/node-problem-detector/values.yaml")
  helm_user_values_override     = file("${path.module}/files/node-problem-detector/values-amd.yaml")

  depends_on = [module.kube_prometheus_stack]
}

module "node_problem_detector_nvidia" {
  count  = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack, local.has_nvidia_gpu]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name     = "gpu-rdma-node-problem-detector-nvidia"
  helm_chart_name     = "node-problem-detector"
  namespace           = var.monitoring_namespace
  helm_repository_url = "oci://ghcr.io/deliveryhero/helm-charts"
  helm_chart_version  = var.node_problem_detector_chart_version

  pre_deployment_commands = [
    "export PATH=$PATH:/home/${local.operator_user}/bin",
    "export OCI_CLI_AUTH=instance_principal"
  ]
  deployment_extra_args    = ["--force", "--dependency-update", "--history-max 1"]
  post_deployment_commands = []

  helm_template_values_override = file("${path.module}/files/node-problem-detector/values.yaml")
  helm_user_values_override     = file("${path.module}/files/node-problem-detector/values-nvidia.yaml")

  depends_on = [module.kube_prometheus_stack]
}


resource "null_resource" "nvidia_dcgm_exporter_service_monitor" {
  count = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack, var.deploy_nvidia_gpu_operator, lookup(var.nvidia_gpu_operator_configuration, "dcgmExporter.enabled", "true") == "true", local.has_nvidia_gpu]) ? 1 : 0

  triggers = {
    manifest_md5    = md5(local.nvidia_dcgm_exporter_service_monitor_manifest)
    bastion_host    = module.oke.bastion_public_ip
    bastion_user    = local.bastion_user
    ssh_private_key = tls_private_key.stack_key.private_key_openssh
    operator_host   = module.oke.operator_private_ip
    operator_user   = local.operator_user
  }

  connection {
    bastion_host        = self.triggers.bastion_host
    bastion_user        = self.triggers.bastion_user
    bastion_private_key = self.triggers.ssh_private_key
    host                = self.triggers.operator_host
    user                = self.triggers.operator_user
    private_key         = self.triggers.ssh_private_key
    timeout             = "40m"
    type                = "ssh"
  }

  provisioner "file" {
    content     = local.nvidia_dcgm_exporter_service_monitor_manifest
    destination = "/tmp/nvidia-dcgm-exporter-service-monitor.yaml"
  }

  provisioner "remote-exec" {
    inline = [
      "export PATH=$PATH:/usr/local/bin:/home/${local.operator_user}/bin",
      "export OCI_CLI_AUTH=instance_principal",
      "for i in $(seq 1 30); do if [ -f ~/.kube/config ] && timeout 10 kubectl cluster-info >/dev/null 2>&1; then echo 'Kubeconfig is ready!'; break; else echo \"Waiting for kubeconfig... ($i/30)\"; sleep 10; fi; done",
      "if ! timeout 30 kubectl cluster-info >/dev/null 2>&1; then echo 'ERROR: Kubeconfig not available after 5 minutes!'; exit 1; fi",
      "kubectl apply -f /tmp/nvidia-dcgm-exporter-service-monitor.yaml",
      "rm -f /tmp/nvidia-dcgm-exporter-service-monitor.yaml"
    ]
  }

  provisioner "remote-exec" {
    when = destroy
    inline = [
      "export PATH=$PATH:/usr/local/bin:/home/${self.triggers.operator_user}/bin",
      "export OCI_CLI_AUTH=instance_principal",
      "kubectl delete servicemonitor nvidia-dcgm-exporter-oke -n gpu-operator --ignore-not-found"
    ]
    on_failure = continue
  }

  lifecycle {
    ignore_changes = [
      triggers["bastion_host"],
      triggers["bastion_user"],
      triggers["ssh_private_key"],
      triggers["operator_host"],
      triggers["operator_user"]
    ]
  }

  depends_on = [
    module.oke,
    module.kube_prometheus_stack,
    oci_containerengine_addon.nvidia_gpu_operator,
  ]
}


module "amd_device_metrics_exporter" {
  count  = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack, var.install_amd_device_metrics_exporter && ((var.worker_rdma_enabled && contains(["BM.GPU.MI300X.8", "BM.GPU.MI355X-v1.8", "BM.GPU.MI355X.8"], var.worker_rdma_shape)) || (var.worker_gpu_enabled && contains(["BM.GPU.MI300X.8", "BM.GPU.MI355X-v1.8", "BM.GPU.MI355X.8"], var.worker_gpu_shape)))]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name     = "amd-device-metrics-exporter"
  helm_chart_name     = "device-metrics-exporter-charts"
  namespace           = var.monitoring_namespace
  helm_repository_url = "https://rocm.github.io/device-metrics-exporter"
  helm_chart_version  = var.amd_device_metrics_exporter_chart_version

  pre_deployment_commands = [
    "export PATH=$PATH:/home/${local.operator_user}/bin",
    "export OCI_CLI_AUTH=instance_principal"
  ]
  deployment_extra_args    = ["--force", "--dependency-update", "--history-max 1"]
  post_deployment_commands = []

  helm_template_values_override = file("${path.module}/files/amd-device-metrics-exporter/values.yaml")
  helm_user_values_override     = ""

  depends_on = [module.kube_prometheus_stack]
}


module "oke-ons-webhook" {
  count  = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack, var.install_grafana, var.setup_alerting]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name    = "oke-ons-webhook"
  namespace          = var.monitoring_namespace
  helm_chart_path    = "${path.module}/files/oke-ons-webhook"
  helm_chart_version = var.oke_ons_webhook_chart_version

  pre_deployment_commands = [
    "export PATH=$PATH:/home/${local.operator_user}/bin",
    "export OCI_CLI_AUTH=instance_principal"
  ]
  deployment_extra_args    = ["--force", "--dependency-update", "--history-max 1"]
  post_deployment_commands = []

  helm_template_values_override = ""
  helm_user_values_override = yamlencode({
    deploy = {
      env = {
        ONS_TOPIC_OCID           = try(oci_ons_notification_topic.grafana_alerts[0].id, "")
        GRAFANA_INITIAL_PASSWORD = base64encode(random_password.grafana_admin_password[0].result)
        GRAFANA_SERVICE_URL      = "http://kube-prometheus-stack-grafana"
      }
    }
  })

  depends_on = [module.kube_prometheus_stack]
}


module "oci_metrics_exporter" {
  count  = alltrue([var.install_monitoring, local.deploy_from_operator, var.install_node_problem_detector_kube_prometheus_stack, var.setup_oci_metrics_exporter]) ? 1 : 0
  source = "./helm-module"

  bastion_host    = module.oke.bastion_public_ip
  bastion_user    = local.bastion_user
  operator_host   = module.oke.operator_private_ip
  operator_user   = local.operator_user
  ssh_private_key = tls_private_key.stack_key.private_key_openssh

  deployment_name    = "oci-metrics-exporter"
  namespace          = var.monitoring_namespace
  helm_chart_path    = "${path.module}/files/oci-metrics-exporter"
  helm_chart_version = var.oci_metrics_exporter_chart_version

  pre_deployment_commands = [
    "export PATH=$PATH:/home/${local.operator_user}/bin",
    "export OCI_CLI_AUTH=instance_principal"
  ]
  deployment_extra_args    = ["--force", "--dependency-update", "--history-max 1"]
  post_deployment_commands = []

  helm_template_values_override = ""
  helm_user_values_override = yamlencode({
    telegraf = {
      streamOcid = try(oci_streaming_stream.oci_metrics_exporter[0].id, "")
    }
  })

  depends_on = [module.kube_prometheus_stack]
}
