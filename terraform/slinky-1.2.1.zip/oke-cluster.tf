# Copyright (c) 2025 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl

data "oci_containerengine_clusters" "oke" {
  compartment_id = var.compartment_ocid
}

locals {

  total_worker_nodes = sum([
    var.worker_ops_pool_size,
    var.worker_cpu_enabled ? var.worker_cpu_pool_size : 0,
    var.worker_gpu_enabled ? var.worker_gpu_pool_size : 0,
    var.worker_rdma_enabled ? var.worker_rdma_pool_size : 0,
    var.worker_gmc_enabled ? length(local.worker_gmc_gpu_memory_fabric_ids) * var.worker_gmc_scale_target_size : 0,
  ])

  deploy_from_operator = alltrue([var.create_bastion, var.create_operator, !var.control_plane_is_public, !var.deploy_to_oke_from_orm])
  deploy_from_local    = alltrue([!local.deploy_from_operator, var.control_plane_is_public, !var.deploy_to_oke_from_orm])
  deploy_from_orm      = alltrue([var.current_user_ocid != null, var.deploy_to_oke_from_orm])

  any_deployments_via_operator = anytrue([
    alltrue([
      local.deploy_from_operator,
      anytrue([
        var.install_monitoring,
        var.install_node_problem_detector_kube_prometheus_stack,
        var.install_mpi_operator,
        var.install_kueue,
        var.install_oci_hpc_oke_utils,
        var.install_nvidia_dra_driver,
        local.deploy_nccl_rccl_param_configmap,
      ])
    ]),
    local.slinky_deploy_from_operator,
  ])

  vcn_name = format("%v-%v", var.vcn_name, local.state_id)

  cluster_endpoints        = module.oke.cluster_endpoints
  cluster_public_endpoint  = try(format("https://%s", lookup(local.cluster_endpoints, "public_endpoint", "not-defined")), "not-defined")
  cluster_private_endpoint = try(format("https://%s", lookup(local.cluster_endpoints, "private_endpoint", "not-defined")), "not-defined")
  cluster_orm_endpoint     = try(format("https://%s:6443", one(data.oci_resourcemanager_private_endpoint_reachable_ip.oke.*.ip_address)), "not-defined")

  cluster_ca_cert = module.oke.cluster_ca_cert

  cluster_id        = module.oke.cluster_id
  cluster_apiserver = try(trimspace(module.oke.apiserver_private_host), "")
  cluster_name      = format("%v-%v", var.cluster_name, local.state_id)

  kube_exec_args = concat(
    ["--region", var.region],
    var.oci_profile != null ? ["--profile", var.oci_profile] : [],
    ["ce", "cluster", "generate-token"],
    ["--cluster-id", module.oke.cluster_id],
  )

  anywhere          = "0.0.0.0/0"
  anywhere_ipv6     = "::/0"
  all_ports         = -1
  all_protocols     = "all"
  icmp_protocol     = 1
  icmpv6_protocol   = 58
  tcp_protocol      = 6
  udp_protocol      = 17
  rule_type_nsg     = "NETWORK_SECURITY_GROUP"
  rule_type_cidr    = "CIDR_BLOCK"
  rule_type_service = "SERVICE_CIDR_BLOCK"

  nsgs = merge(
    {
      bastion  = var.create_bastion ? { create = "auto" } : { create = "never" }
      operator = var.create_operator ? { create = "auto" } : { create = "never" }
      int_lb   = { create = "auto" }
      pub_lb   = { create = "auto" }
      cp       = { create = "auto" }
      workers  = { create = "auto" }
      pods     = { create = "auto" }
    },
    local.create_fss_effective ? {
      fss = { create = "always" }
    } : {}
  )

  subnets = merge(
    {
      bastion = merge(
        var.create_bastion ? { create = "auto" } : { create = "never" },
        (var.create_vcn && var.bastion_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 13, netnum = 1 } : {},
        var.create_vcn && var.bastion_sn_cidr != null ?
        { cidr = var.bastion_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.bastion_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "bastion", {})
      )
      operator = merge(
        var.create_operator ? { create = "auto" } : { create = "never" },
        (var.create_vcn && var.operator_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 13, netnum = 2 } : {},
        var.create_vcn && var.operator_sn_cidr != null ?
        { cidr = var.operator_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.operator_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "operator", {})
      )
      int_lb = merge(
        { create = "auto" },
        (var.create_vcn && var.int_lb_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 11, netnum = 1 } : {},
        var.create_vcn && var.int_lb_sn_cidr != null ?
        { cidr = var.int_lb_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.int_lb_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "int_lb", {})
      )
      pub_lb = merge(
        { create = "auto" },
        (var.create_vcn && var.pub_lb_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 11, netnum = 2 } : {},
        var.create_vcn && var.pub_lb_sn_cidr != null ?
        { cidr = var.pub_lb_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.pub_lb_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "pub_lb", {})
      )
      cp = merge(
        { create = "auto" },
        (var.create_vcn && var.cp_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 13, netnum = 0 } : {},
        var.create_vcn && var.cp_sn_cidr != null ?
        { cidr = var.cp_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.cp_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "cp", {})
      )
      workers = merge(
        { create = "auto" },
        (var.create_vcn && var.workers_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 3, netnum = 2 } : {},
        var.create_vcn && var.workers_sn_cidr != null ?
        { cidr = var.workers_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.workers_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "workers", {})
      )
      pods = merge(
        { create = "auto" },
        (var.create_vcn && var.pods_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 1, netnum = 1 } : {},
        var.create_vcn && var.pods_sn_cidr != null ?
        { cidr = var.pods_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.pods_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "pods", {})
      )
      bastion_service = merge(
        var.create_oci_bastion_service ? { create = "auto" } : { create = "never" },
        (var.create_vcn && var.bastion_service_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 11, netnum = 4 } : {},
        var.create_vcn && var.bastion_service_sn_cidr != null ?
        { cidr = var.bastion_service_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.bastion_service_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "bastion_service", {})
      )
    },
    local.create_fss_effective ? {
      fss = merge(
        { create = "always" },
        (var.create_vcn && var.fss_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 11, netnum = 3 } : {},
        var.create_vcn && var.fss_sn_cidr != null ?
        { cidr = var.fss_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.fss_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "fss", {})
      )
    } : {},
    var.create_lustre ? {
      lustre = merge(
        { create = "always" },
        (var.create_vcn && var.lustre_sn_cidr == null) || (!var.create_vcn && !var.custom_subnet_ids) ?
        { newbits = 7, netnum = 1 } : {},
        var.create_vcn && var.lustre_sn_cidr != null ?
        { cidr = var.lustre_sn_cidr } : {},
        !var.create_vcn && var.custom_subnet_ids ?
        { id = var.lustre_sn_id, create = "never" } : {},
        lookup(var.subnet_advanced_attrs, "lustre", {})
      )
    } : {}
  )

  cni_type = contains(["npn", "VCN-Native Pod Networking"], var.cni_type) ? "npn" : "flannel"

  operator_denseio_ocpus = {
    "VM.DenseIO.E4.Flex" = var.operator_shape_ocpus_denseIO_e4_flex,
    "VM.DenseIO.E5.Flex" = var.operator_shape_ocpus_denseIO_e5_flex
  }
  operator_denseio_memory = {
    "VM.DenseIO.E4.Flex" = 16 * var.operator_shape_ocpus_denseIO_e4_flex,
    "VM.DenseIO.E5.Flex" = 12 * var.operator_shape_ocpus_denseIO_e5_flex
  }

  bastion_image_type  = lower(var.bastion_image_type)
  bastion_image_id    = var.bastion_image_use_uri ? lookup(lookup(oci_core_image.imported_image, var.bastion_image_custom_uri, {}), "id", null) : var.bastion_image_id
  operator_image_type = lower(var.operator_image_type)
  operator_image_id   = var.operator_image_use_uri ? lookup(lookup(oci_core_image.imported_image, var.operator_image_custom_uri, {}), "id", null) : var.operator_image_id

  bastion_image_operating_system         = local.bastion_image_type == "custom" ? coalesce(try(one(data.oci_core_image.bastion_selected[*].operating_system), null), var.bastion_image_os) : var.bastion_image_os
  bastion_image_operating_system_version = local.bastion_image_type == "custom" ? coalesce(try(one(data.oci_core_image.bastion_selected[*].operating_system_version), null), var.bastion_image_os_version) : var.bastion_image_os_version
  operator_image_operating_system        = local.operator_image_type == "custom" ? coalesce(try(one(data.oci_core_image.operator_selected[*].operating_system), null), var.operator_image_os) : var.operator_image_os
  operator_image_operating_system_version = local.operator_image_type == "custom" ? coalesce(
    try(one(data.oci_core_image.operator_selected[*].operating_system_version), null),
    var.operator_image_os_version
  ) : var.operator_image_os_version
  bastion_user = lower(var.bastion_user) == "auto" ? (
    local.bastion_image_operating_system != null && can(regex("(?i)oracle.*linux", local.bastion_image_operating_system)) ? "opc" : "ubuntu"
  ) : var.bastion_user
  operator_user = lower(var.operator_user) == "auto" ? (
    local.operator_image_operating_system != null && can(regex("(?i)oracle.*linux", local.operator_image_operating_system)) ? "opc" : "ubuntu"
  ) : var.operator_user
}

data "oci_core_image" "bastion_selected" {
  count = var.create_bastion && local.bastion_image_type == "custom" && (var.bastion_image_use_uri || coalesce(var.bastion_image_id, "none") != "none") ? 1 : 0

  image_id = local.bastion_image_id
}

data "oci_core_image" "operator_selected" {
  count = var.create_operator && local.operator_image_type == "custom" && (var.operator_image_use_uri || coalesce(var.operator_image_id, "none") != "none") ? 1 : 0

  image_id = local.operator_image_id
}

module "oke" {
  source  = "oracle-terraform-modules/oke/oci"
  version = "5.5.0"

  providers = { oci.home = oci.home }

  region         = var.region
  tenancy_id     = var.tenancy_ocid
  compartment_id = var.compartment_ocid
  state_id       = local.state_id

  assign_public_ip_to_control_plane = var.create_public_subnets ? var.control_plane_is_public : false

  allow_bastion_cluster_access = true
  allow_node_port_access       = true
  allow_worker_internet_access = true
  allow_worker_ssh_access      = true
  assign_dns                   = true
  bastion_allowed_cidrs        = flatten(tolist([var.bastion_allowed_cidrs]))
  bastion_await_cloudinit      = false
  bastion_is_public            = var.create_public_subnets ? var.bastion_is_public : false
  bastion_image_type           = local.bastion_image_type
  bastion_image_id             = local.bastion_image_id
  bastion_image_os             = local.bastion_image_operating_system
  bastion_image_os_version     = local.bastion_image_operating_system_version
  bastion_user                 = local.bastion_user
  bastion_shape = {
    shape            = var.bastion_shape_name,
    ocpus            = var.bastion_shape_ocpus,
    memory           = var.bastion_shape_memory,
    boot_volume_size = 50
  }
  bastion_upgrade = false

  cluster_name                       = local.cluster_name
  cluster_type                       = "enhanced"
  cni_type                           = local.cni_type
  control_plane_allowed_cidrs        = flatten(tolist([var.control_plane_allowed_cidrs]))
  control_plane_is_public            = var.control_plane_is_public
  create_bastion                     = var.create_bastion
  create_cluster                     = true
  create_iam_defined_tags            = false
  create_iam_resources               = false
  create_iam_tag_namespace           = false
  create_operator                    = var.create_operator
  create_vcn                         = var.create_vcn
  enable_ipv6                        = var.enable_ipv6
  kubernetes_version                 = var.kubernetes_version
  load_balancers                     = var.create_public_subnets ? "both" : "internal"
  lockdown_default_seclist           = true
  max_pods_per_node                  = var.max_pods_per_node
  operator_image_type                = local.operator_image_type
  operator_image_id                  = local.operator_image_id
  operator_image_os                  = local.operator_image_operating_system
  operator_image_os_version          = local.operator_image_operating_system_version
  operator_user                      = local.operator_user
  operator_await_cloudinit           = local.any_deployments_via_operator ? true : false
  operator_install_kubectl_from_repo = true
  operator_install_helm_from_repo    = true
  operator_install_oci_cli_from_repo = true
  operator_install_k9s               = true
  operator_install_kubectx           = true
  operator_allow_image_drift         = var.operator_allow_image_drift
  operator_shape = {
    shape            = var.operator_shape_name
    ocpus            = lookup(local.operator_denseio_ocpus, var.operator_shape_name, var.operator_shape_ocpus)
    memory           = lookup(local.operator_denseio_memory, var.operator_shape_name, var.operator_shape_memory)
    boot_volume_size = var.operator_shape_boot
  }
  output_detail                     = true
  pods_cidr                         = "10.240.0.0/12"
  services_cidr                     = var.services_cidr
  kubeproxy_mode                    = var.kubeproxy_mode
  preferred_load_balancer           = var.preferred_kubernetes_services
  ssh_public_key                    = trimspace(local.ssh_public_key)
  ssh_private_key                   = local.any_deployments_via_operator ? tls_private_key.stack_key.private_key_openssh : null
  use_defined_tags                  = false
  vcn_cidrs                         = split(",", var.vcn_cidrs)
  vcn_create_internet_gateway       = var.create_public_subnets ? "auto" : "never"
  vcn_create_nat_gateway            = "auto"
  vcn_create_service_gateway        = "auto"
  nat_route_table_id                = var.private_subnet_route_table
  ig_route_table_id                 = var.public_subnet_route_table
  vcn_id                            = var.vcn_id
  vcn_name                          = local.vcn_name
  worker_disable_default_cloud_init = true
  worker_is_public                  = false
  worker_pools                      = local.worker_pools
  subnets                           = local.subnets
  nsgs                              = local.nsgs
  use_stateless_rules               = var.use_stateless_rules

  allow_rules_internal_lb = {
    "Allow TCP ingress to internal load balancers from internal VCN/DRG" = {
      protocol = local.all_protocols, port = local.all_ports, source = local.vcn_cidr, source_type = local.rule_type_cidr,
    }
  }

  allow_rules_public_lb = merge(
    alltrue([var.install_node_problem_detector_kube_prometheus_stack, var.preferred_kubernetes_services == "public"]) ? {
      "Allow TCP ingress from anywhere to HTTP port" = {
        protocol = local.tcp_protocol, port = 80, source = local.anywhere, source_type = local.rule_type_cidr,
      },
      "Allow TCP ingress from anywhere to HTTPS port" = {
        protocol = local.tcp_protocol, port = 443, source = local.anywhere, source_type = local.rule_type_cidr,
      }
    } : {},
    alltrue([
      var.install_slinky,
      var.slinky_install_slurm_cluster,
      var.slinky_login_enabled,
      var.preferred_kubernetes_services == "public",
      ]) ? {
      "Allow TCP ingress from anywhere to Slurm login SSH port" = {
        protocol = local.tcp_protocol, port = 22, source = local.anywhere, source_type = local.rule_type_cidr,
      }
    } : {},
  )

  allow_rules_workers = var.create_lustre ? {
    "Allow ingress from Lustre to OKE Workers" = {
      protocol = local.tcp_protocol, source_port_min = 512, source_port_max = 1023, destination_port_min = 988, destination_port_max = 988, source = one(oci_core_network_security_group.lustre_nsg[*].id), source_type = local.rule_type_nsg,
    }
    "Allow egress from Workers to Lustre" = {
      protocol = local.tcp_protocol, source_port_min = 512, source_port_max = 1023, destination_port_min = 988, destination_port_max = 988, destination = one(oci_core_network_security_group.lustre_nsg[*].id), destination_type = local.rule_type_nsg,
    }
  } : {}

  depends_on = [
    null_resource.validate_bastion_networking, null_resource.validate_cluster_endpoint, null_resource.validate_cluster_services
  ]
}
