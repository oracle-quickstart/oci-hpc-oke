# Copyright (c) 2025 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl

# Terraform
output "state_id" { value = module.oke.state_id }
output "stack_version" { value = "v26.7.0" }

# Network
output "vcn_id" { value = module.oke.vcn_id }
output "vcn_name" { value = local.vcn_name }
output "ig_route_table_id" { value = module.oke.ig_route_table_id }
output "nat_route_table_id" { value = module.oke.nat_route_table_id }

# Bastion
output "bastion_id" { value = module.oke.bastion_id }
output "bastion_public_ip" { value = module.oke.bastion_public_ip }
output "bastion_ssh_command" { value = var.create_bastion ? module.oke.ssh_to_bastion : "" }
output "bastion_image_type" {
  description = "Image selection mode used for the bastion instance."
  value       = var.create_bastion ? local.bastion_image_type : ""
}
output "bastion_image_id" {
  description = "Image OCID used for the bastion instance."
  value       = var.create_bastion && local.bastion_image_id != null ? local.bastion_image_id : ""
}
output "bastion_image_os" {
  description = "Operating system name for the bastion instance image."
  value       = var.create_bastion ? coalesce(local.bastion_image_operating_system, "") : ""
}
output "bastion_image_os_version" {
  description = "Operating system version for the bastion instance image."
  value       = var.create_bastion ? coalesce(local.bastion_image_operating_system_version, "") : ""
}
output "bastion_ssh_user" {
  description = "SSH username selected for the bastion instance."
  value       = var.create_bastion ? local.bastion_user : ""
}
output "bastion_subnet_id" { value = module.oke.bastion_subnet_id }
output "bastion_subnet_cidr" { value = module.oke.bastion_subnet_cidr }
output "bastion_nsg_id" { value = module.oke.bastion_nsg_id }

# Bastion Service
output "bastion_service_id" { value = var.create_oci_bastion_service ? one(oci_bastion_bastion.bastion_service[*].id) : "" }
output "bastion_service_subnet_id" { value = var.create_oci_bastion_service ? local.bastion_service_subnet_id : "" }
output "bastion_service_subnet_cidr" { value = var.create_oci_bastion_service ? local.bastion_service_subnet_cidr : "" }
output "bastion_service_security_list_id" { value = var.create_oci_bastion_service ? one(oci_core_security_list.bastion_service[*].id) : "" }
output "oke_private_endpoint_ip" { value = var.create_oci_bastion_service ? local.oke_private_endpoint_ip : "" }
output "bastion_service_session_command" {
  value = var.create_oci_bastion_service ? format(
    "./oke-bastion-service-session.sh --bastion-ocid %s --cluster-ocid %s --oke-endpoint-ip %s --region %s --profile %s --ssh-key %s --local-port %d --ttl-seconds %d --auto-tunnel --non-interactive",
    one(oci_bastion_bastion.bastion_service[*].id),
    module.oke.cluster_id,
    local.oke_private_endpoint_ip,
    var.region,
    var.oci_profile != null ? var.oci_profile : "DEFAULT",
    "~/.ssh/id_rsa",
    6443,
    10800,
  ) : ""
}
output "bastion_service_worker_ssh_command" {
  value = var.create_oci_bastion_service && var.bastion_service_allow_worker_ssh ? format(
    "./oke-bastion-service-session.sh --bastion-ocid %s --worker-ip <worker-ip> --region %s --profile %s --ssh-key %s --ttl-seconds %d --auto-tunnel --non-interactive",
    one(oci_bastion_bastion.bastion_service[*].id),
    var.region,
    var.oci_profile != null ? var.oci_profile : "DEFAULT",
    "~/.ssh/id_rsa",
    10800,
  ) : ""
}

# Operator
output "operator_id" { value = module.oke.operator_id }
output "operator_private_ip" { value = module.oke.operator_private_ip }
output "operator_ssh_command" { value = var.create_operator ? module.oke.ssh_to_operator : "" }
output "operator_image_type" {
  description = "Image selection mode used for the operator instance."
  value       = var.create_operator ? local.operator_image_type : ""
}
output "operator_image_id" {
  description = "Image OCID used for the operator instance."
  value       = var.create_operator && local.operator_image_id != null ? local.operator_image_id : ""
}
output "operator_image_os" {
  description = "Operating system name for the operator instance image."
  value       = var.create_operator ? coalesce(local.operator_image_operating_system, "") : ""
}
output "operator_image_os_version" {
  description = "Operating system version for the operator instance image."
  value       = var.create_operator ? coalesce(local.operator_image_operating_system_version, "") : ""
}
output "operator_ssh_user" {
  description = "SSH username selected for the operator instance."
  value       = var.create_operator ? local.operator_user : ""
}
output "operator_subnet_id" { value = module.oke.operator_subnet_id }
output "operator_subnet_cidr" { value = module.oke.operator_subnet_cidr }
output "operator_nsg_id" { value = module.oke.operator_nsg_id }

# Cluster
output "cni_type" { value = var.cni_type }
output "cluster_id" { value = module.oke.cluster_id }
output "cluster_name" { value = local.cluster_name }
output "cluster_public_endpoint" { value = var.control_plane_is_public ? local.cluster_public_endpoint : "" }
output "cluster_private_endpoint" { value = local.cluster_private_endpoint }
output "cluster_ca_cert" { value = base64decode(module.oke.cluster_ca_cert) }
output "control_plane_subnet_id" { value = module.oke.control_plane_subnet_id }
output "control_plane_subnet_cidr" { value = module.oke.control_plane_subnet_cidr }
output "control_plane_nsg_id" { value = module.oke.control_plane_nsg_id }
output "int_lb_subnet_id" { value = module.oke.int_lb_subnet_id }
output "int_lb_subnet_cidr" { value = module.oke.int_lb_subnet_cidr }
output "int_lb_nsg_id" { value = module.oke.int_lb_nsg_id }
output "pub_lb_subnet_id" { value = module.oke.pub_lb_subnet_id }
output "pub_lb_subnet_cidr" { value = module.oke.pub_lb_subnet_cidr }
output "pub_lb_nsg_id" { value = module.oke.pub_lb_nsg_id }
output "pod_subnet_id" { value = module.oke.pod_subnet_id }
output "pod_subnet_cidr" { value = module.oke.pod_subnet_cidr }
output "pod_nsg_id" { value = module.oke.pod_nsg_id }
output "lustre_subnet_id" { value = one(oci_core_subnet.lustre_subnet[*].id) }
output "lustre_nsg_id" { value = one(oci_core_network_security_group.lustre_nsg[*].id) }
output "lustre_file_system_id" { value = one(oci_lustre_file_storage_lustre_file_system.lustre[*].id) }
output "lustre_management_service_address" { value = one(oci_lustre_file_storage_lustre_file_system.lustre[*].management_service_address) }
output "fss_file_system_id" { value = one(oci_file_storage_file_system.fss[*].id) }
output "fss_mount_target_ip" { value = one(data.oci_core_private_ip.fss_mt_ip[*].ip_address) }
output "fss_export_path" { value = one(oci_file_storage_export.FSSExport[*].path) }
output "fss_nsg_id" { value = module.oke.fss_nsg_id }
output "fss_subnet_id" { value = module.oke.fss_subnet_id }
output "fss_mount_path" { value = var.fss_mount_path }
output "lustre_mount_path" { value = var.lustre_mount_path }

# Workers
output "worker_subnet_id" { value = module.oke.worker_subnet_id }
output "worker_nsg_id" { value = module.oke.worker_nsg_id }
output "worker_subnet_cidr" { value = module.oke.worker_subnet_cidr }
output "worker_ops_pool_id" { value = lookup(module.oke.worker_pool_ids, "oke-system", null) }
output "worker_cpu_pool_id" { value = lookup(module.oke.worker_pool_ids, "oke-cpu", null) }
output "worker_gpu_pool_id" { value = lookup(module.oke.worker_pool_ids, "oke-gpu", null) }
output "worker_rdma_pool_id" { value = lookup(module.oke.worker_pool_ids, "oke-rdma", null) }

# Monitoring
output "grafana_fetch_endpoint_command" {
  value = var.install_grafana ? (alltrue([var.install_node_problem_detector_kube_prometheus_stack, var.preferred_kubernetes_services == "public"]) ? format("kubectl get ingress -n %v -l app.kubernetes.io/instance=kube-prometheus-stack -o jsonpath='{.items[0].spec.rules[0].host}'", var.monitoring_namespace) : format("kubectl get svc -n %v -l app.kubernetes.io/instance=kube-prometheus-stack,app.kubernetes.io/name=grafana -o jsonpath='{.items[0].status.loadBalancer.ingress[0].ip}'", var.monitoring_namespace)) : "N/A"
}

output "grafana_url" {
  value = var.install_node_problem_detector_kube_prometheus_stack && var.install_grafana ? (
    var.preferred_kubernetes_services == "public" ?
    format("https://grafana.%s.%s", try(data.kubernetes_service_v1.ingress_lb[0].status[0].load_balancer[0].ingress[0].ip, try(data.oci_load_balancer_load_balancers.lbs[0].load_balancers[0].ip_addresses[0], "N/A")), var.wildcard_dns_domain) :
    format("http://%s", try(data.kubernetes_service_v1.grafana_internal_ip[0].status[0].load_balancer[0].ingress[0].ip, try(data.oci_load_balancer_load_balancers.lbs[0].load_balancers[0].ip_addresses[0], try(data.oci_load_balancer_load_balancers.internal_lbs[0].load_balancers[0].ip_addresses[0], "N/A"))))
  ) : "N/A"
}

output "grafana_admin_password" {
  value = var.install_grafana ? nonsensitive(random_password.grafana_admin_password[0].result) : "N/A"
}

output "grafana_admin_username" {
  value = var.install_grafana ? "admin" : "N/A"
}

output "slinky_login_fetch_ip_command" {
  value = alltrue([
    var.install_slinky,
    var.slinky_install_slurm_cluster,
    var.slinky_login_enabled,
  ]) ? format("kubectl -n %s get svc slurm-login-slinky -o jsonpath='{.status.loadBalancer.ingress[0].ip}'", var.slinky_slurm_namespace) : "N/A"
}

output "slinky_openldap_admin_password" {
  description = "OpenLDAP adminPassword used by the Slinky identity deployment."
  value       = var.install_slinky && var.slinky_identity_enabled ? local.slinky_openldap_admin_password : null
  sensitive   = true
}

output "slinky_openldap_config_password" {
  description = "OpenLDAP configPassword used by the Slinky identity deployment."
  value       = var.install_slinky && var.slinky_identity_enabled ? local.slinky_openldap_config_password : null
  sensitive   = true
}

output "prom_server_port_forward" {
  value = format("kubectl port-forward -n %v svc/kube-prometheus-stack-prometheus 9090:9090", var.monitoring_namespace)
}

output "grafana_port_forward" {
  value = var.install_grafana ? format("kubectl port-forward -n %v svc/kube-prometheus-stack-grafana 3000:80", var.monitoring_namespace) : "N/A"
}

output "access_k8s_public_endpoint" {
  value = var.control_plane_is_public ? format("oci ce cluster create-kubeconfig --cluster-id %v --file $HOME/.kube/config --region %v --token-version 2.0.0 --kube-endpoint PUBLIC_ENDPOINT", module.oke.cluster_id, var.region) : "N/A"
}

output "access_k8s_private_endpoint" {
  value = format("oci ce cluster create-kubeconfig --cluster-id %v --file $HOME/.kube/config --region %v --token-version 2.0.0 --kube-endpoint PRIVATE_ENDPOINT", module.oke.cluster_id, var.region)
}

# output "cluster_orm_endpoint" {
#   value = local.cluster_orm_endpoint
# }

# output "deploy_to_oke_from_orm" {
#   value = var.deploy_to_oke_from_orm
# }

# output "current_user_ocid" {
#   value = var.current_user_ocid
# }
