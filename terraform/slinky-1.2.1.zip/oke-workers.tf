# Copyright (c) 2025 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl

locals {
  create_workers      = true
  fss_mount_ip        = try(data.oci_core_private_ip.fss_mt_ip[0].ip_address, "")
  lustre_mount_ip     = try(oci_lustre_file_storage_lustre_file_system.lustre[0].management_service_address, "")
  ssh_authorized_keys = compact(split("\n", trimspace(local.ssh_public_key)))

  worker_ops_image_type = contains(["platform", "custom"], lower(var.worker_ops_image_type)) ? "custom" : "oke"
  worker_ops_image_id   = var.worker_ops_image_use_uri ? lookup(lookup(oci_core_image.imported_image, var.worker_ops_image_custom_uri, {}), "id", null) : coalesce(var.worker_ops_image_custom_id, var.worker_ops_image_platform_id, "none")
  worker_cpu_denseio_ocpus = {
    "VM.DenseIO.E4.Flex" = var.worker_cpu_ocpus_denseIO_e4_flex,
    "VM.DenseIO.E5.Flex" = var.worker_cpu_ocpus_denseIO_e5_flex
  }
  worker_cpu_denseio_memory = {
    "VM.DenseIO.E4.Flex" = 16 * var.worker_cpu_ocpus_denseIO_e4_flex,
    "VM.DenseIO.E5.Flex" = 12 * var.worker_cpu_ocpus_denseIO_e5_flex
  }
  worker_cpu_image_type  = contains(["platform", "custom"], lower(var.worker_cpu_image_type)) ? "custom" : "oke"
  worker_cpu_image_id    = var.worker_cpu_image_use_uri ? lookup(lookup(oci_core_image.imported_image, var.worker_cpu_image_custom_uri, {}), "id", null) : coalesce(var.worker_cpu_image_custom_id, var.worker_cpu_image_platform_id, "none")
  worker_gpu_image_type  = contains(["platform", "custom"], lower(var.worker_gpu_image_type)) ? "custom" : "oke"
  worker_gpu_image_id    = var.worker_gpu_image_use_uri ? lookup(lookup(oci_core_image.imported_image, var.worker_gpu_image_custom_uri, {}), "id", null) : coalesce(var.worker_gpu_image_custom_id, var.worker_gpu_image_platform_id, "none")
  worker_rdma_image_type = contains(["platform", "custom"], lower(var.worker_rdma_image_type)) ? "custom" : "oke"
  worker_rdma_image_id   = var.worker_rdma_image_use_uri ? lookup(lookup(oci_core_image.imported_image, var.worker_rdma_image_custom_uri, {}), "id", null) : coalesce(var.worker_rdma_image_custom_id, var.worker_rdma_image_platform_id, "none")
  worker_gmc_gpu_memory_fabric_ids = compact([
    for id in split("\n", trimspace(var.worker_gmc_gpu_memory_fabric_ids)) : trimspace(id)
  ])
  hostname_override_effective = coalesce(var.hostname_override, false)

  runcmd_bootstrap = local.create_workers ? format(
    "curl -sL -o /var/run/oke-ubuntu-cloud-init.sh https://raw.githubusercontent.com/oracle-quickstart/oci-hpc-oke/refs/heads/main/files/oke-ubuntu-cloud-init.sh && (bash /var/run/oke-ubuntu-cloud-init.sh '%v' '%v' '%v' || echo 'Error bootstrapping OKE' >&2)",
    var.kubernetes_version, var.setup_credential_provider_for_ocir, local.hostname_override_effective
  ) : ""

  runcmd_nvme_raid = var.nvme_raid_enabled ? format(
    "curl -sL -o /var/run/oke-nvme-raid.sh https://raw.githubusercontent.com/oracle-quickstart/oci-hpc-oke/refs/heads/main/files/oke-nvme-raid.sh && (bash /var/run/oke-nvme-raid.sh '%v' || echo 'Error initializing RAID' >&2)",
    var.nvme_raid_level,
  ) : ""

  runcmd_fss_mount = local.create_fss_effective && local.fss_mount_ip != "" && local.fss_export_path != "" ? format(
    "curl -sL -o /var/run/oke-fss-mount.sh https://raw.githubusercontent.com/oracle-quickstart/oci-hpc-oke/refs/heads/main/files/oke-fss-mount.sh && (bash /var/run/oke-fss-mount.sh '%v' '%v' '%v' || echo 'Error mounting FSS' >&2)",
    local.fss_export_path, var.fss_mount_path, local.fss_mount_ip
  ) : ""

  runcmd_lustre_mount = var.create_lustre && local.lustre_mount_ip != "" ? format(
    "curl -sL -o /var/run/oke-lustre-mount.sh https://raw.githubusercontent.com/oracle-quickstart/oci-hpc-oke/refs/heads/main/files/oke-lustre-mount.sh && (bash /var/run/oke-lustre-mount.sh '%v' '%v' '%v' || echo 'Error mounting Lustre' >&2)",
    local.lustre_mount_ip, var.lustre_file_system_name, var.lustre_mount_path
  ) : ""

  write_files = [
    {
      content = local.cluster_apiserver,
      path    = "/etc/oke/oke-apiserver",
    },
    {
      encoding    = "b64",
      content     = local.cluster_ca_cert,
      owner       = "root:root",
      path        = "/etc/kubernetes/ca.crt",
      permissions = "0644",
    },
    {
      content     = <<-EOT
      [Network]
      ManageForeignRoutes=no
      ManageForeignRoutingPolicyRules=no
      EOT
      owner       = "root:root",
      path        = "/etc/systemd/networkd.conf",
      permissions = "0644"
    }
  ]
  cloud_init = {
    ssh_authorized_keys = local.ssh_authorized_keys
    runcmd = compact([
      local.runcmd_nvme_raid,
      local.runcmd_bootstrap,
      local.runcmd_fss_mount,
      local.runcmd_lustre_mount,
      "if . /etc/os-release && [ \"$ID\" = \"ubuntu\" ]; then systemctl restart systemd-networkd && echo 'networkd patched' || echo 'networkd not patched'; fi",
    ])
    write_files = local.write_files
  }

  node_metadata = merge(
    var.oke_pre_bootstrap_script != "" ? { "pre_oke" : base64encode(var.oke_pre_bootstrap_script) } : {},
    var.oke_kubelet_extra_args != "" ? { "kubelet-extra-args" : var.oke_kubelet_extra_args } : {},
    var.oke_post_bootstrap_script != "" ? { "post_oke" : base64encode(var.oke_post_bootstrap_script) } : {},
  )

  supported_worker_ops_max_pods_per_node = anytrue([strcontains(var.worker_ops_shape, "Flex"), strcontains(var.worker_ops_shape, "Generic")]) ? (var.worker_ops_ocpus <= 2 ? 31 : (var.worker_ops_ocpus - 1) * 31) : var.max_pods_per_node
  supported_worker_cpu_max_pods_per_node = alltrue([anytrue([strcontains(var.worker_cpu_shape, "Flex"), strcontains(var.worker_cpu_shape, "Generic")]), !strcontains(var.worker_cpu_shape, "DenseIO")]) ? (var.worker_cpu_ocpus <= 2 ? 31 : (var.worker_cpu_ocpus - 1) * 31) : var.max_pods_per_node

  worker_ops_max_pods_per_node = min(local.supported_worker_ops_max_pods_per_node, var.worker_ops_max_pods_per_node)
  worker_cpu_max_pods_per_node = min(local.supported_worker_cpu_max_pods_per_node, var.worker_cpu_max_pods_per_node)

  worker_pools = {
    "oke-system" = {
      create                       = local.create_workers
      description                  = "OKE-managed VM Node Pool for cluster operations and monitoring"
      placement_ads                = [substr(var.worker_ops_ad, -1, 0)]
      mode                         = "node-pool"
      size                         = var.worker_ops_pool_size
      shape                        = var.worker_ops_shape
      ocpus                        = var.worker_ops_ocpus
      memory                       = var.worker_ops_memory
      boot_volume_size             = var.worker_ops_boot_volume_size
      image_type                   = local.worker_ops_image_type
      os                           = var.worker_ops_image_os
      os_version                   = var.worker_ops_image_os_version
      image_id                     = local.worker_ops_image_id
      max_pods_per_node            = local.worker_ops_max_pods_per_node
      kubernetes_version           = coalesce(var.worker_ops_kubernetes_version, var.kubernetes_version)
      node_cycling_enabled         = var.worker_ops_node_cycling_enabled
      node_cycling_max_surge       = var.worker_ops_node_cycling_max_surge
      node_cycling_max_unavailable = var.worker_ops_node_cycling_max_unavailable
      node_cycling_mode            = [var.worker_ops_node_cycling_mode]
      node_metadata = merge(
        { "areLegacyImdsEndpointsDisabled" : var.legacy_imds_endpoints_disabled },
        local.node_metadata
      )
      cloud_init = [{ content_type = "text/cloud-config", content = yamlencode(local.cloud_init) }]
    }
    "oke-cpu" = {
      create                       = local.create_workers && var.worker_cpu_enabled
      description                  = "OKE-managed CPU Node Pool"
      placement_ads                = [substr(var.worker_cpu_ad, -1, 0)]
      mode                         = "node-pool"
      size                         = var.worker_cpu_pool_size
      shape                        = var.worker_cpu_shape
      ocpus                        = lookup(local.worker_cpu_denseio_ocpus, var.worker_cpu_shape, var.worker_cpu_ocpus)
      memory                       = lookup(local.worker_cpu_denseio_memory, var.worker_cpu_shape, var.worker_cpu_memory)
      boot_volume_size             = var.worker_cpu_boot_volume_size
      image_type                   = local.worker_cpu_image_type
      os                           = var.worker_cpu_image_os
      os_version                   = var.worker_cpu_image_os_version
      image_id                     = local.worker_cpu_image_id
      max_pods_per_node            = local.worker_cpu_max_pods_per_node
      kubernetes_version           = coalesce(var.worker_cpu_kubernetes_version, var.kubernetes_version)
      node_cycling_enabled         = var.worker_cpu_node_cycling_enabled
      node_cycling_max_surge       = var.worker_cpu_node_cycling_max_surge
      node_cycling_max_unavailable = var.worker_cpu_node_cycling_max_unavailable
      node_cycling_mode            = [var.worker_cpu_node_cycling_mode]
      node_metadata = merge(
        { "areLegacyImdsEndpointsDisabled" : var.legacy_imds_endpoints_disabled },
        local.node_metadata
      )
      cloud_init  = [{ content_type = "text/cloud-config", content = yamlencode(local.cloud_init) }]
      node_labels = var.install_slinky && !var.slinky_hostname_prefix_disabled ? { "oci.oraclecloud.com/slinky-hostname-prefix" = local.slinky_cpu_hostname_prefix } : {}
    }
    "oke-gpu" = {
      create             = local.create_workers && var.worker_gpu_enabled
      description        = "OKE-managed GPU Node Pool"
      placement_ads      = [substr(var.worker_gpu_ad, -1, 0)]
      mode               = "node-pool"
      size               = var.worker_gpu_pool_size
      shape              = var.worker_gpu_shape
      boot_volume_size   = var.worker_gpu_boot_volume_size
      image_type         = local.worker_gpu_image_type
      os                 = var.worker_gpu_image_os
      os_version         = var.worker_gpu_image_os_version
      image_id           = local.worker_gpu_image_id
      max_pods_per_node  = var.worker_gpu_max_pods_per_node
      kubernetes_version = coalesce(var.worker_gpu_kubernetes_version, var.kubernetes_version)
      node_labels = merge(
        { "oci.oraclecloud.com/disable-gpu-device-plugin" = var.disable_gpu_device_plugin ? "true" : "false" },
        var.install_slinky && !var.slinky_hostname_prefix_disabled ? { "oci.oraclecloud.com/slinky-hostname-prefix" = local.slinky_gpu_hostname_prefix } : {},
      )
      node_cycling_enabled         = var.worker_gpu_node_cycling_enabled
      node_cycling_max_surge       = var.worker_gpu_node_cycling_max_surge
      node_cycling_max_unavailable = var.worker_gpu_node_cycling_max_unavailable
      node_cycling_mode            = [var.worker_gpu_node_cycling_mode]
      node_metadata = merge(
        { "areLegacyImdsEndpointsDisabled" : var.legacy_imds_endpoints_disabled },
        local.node_metadata
      )
      cloud_init = [{ content_type = "text/cloud-config", content = yamlencode(local.cloud_init) }]
    }
    "oke-rdma" = {
      create                         = local.create_workers && var.worker_rdma_enabled && !local.invalid_worker_rdma_image
      description                    = "OKE pool with RDMA"
      placement_ads                  = [substr(var.worker_rdma_ad, -1, 0)]
      mode                           = var.worker_rdma_use_cluster_network ? "cluster-network" : "node-pool"
      use_compute_cluster            = !var.worker_rdma_use_cluster_network
      host_group_id                  = var.worker_rdma_host_group_id
      size                           = var.worker_rdma_pool_size
      shape                          = var.worker_rdma_shape
      boot_volume_size               = var.worker_rdma_boot_volume_size
      boot_volume_vpus_per_gb        = var.worker_rdma_boot_volume_vpus_per_gb
      image_type                     = "custom" # only custom is supported.
      image_id                       = local.worker_rdma_image_id
      max_pods_per_node              = var.worker_rdma_max_pods_per_node
      kubernetes_version             = coalesce(var.worker_rdma_kubernetes_version, var.kubernetes_version)
      legacy_imds_endpoints_disabled = var.legacy_imds_endpoints_disabled
      cloud_init                     = [{ content_type = "text/cloud-config", content = yamlencode(local.cloud_init) }]
      node_metadata                  = local.node_metadata
      node_labels = merge(
        { "oci.oraclecloud.com/disable-gpu-device-plugin" = var.disable_gpu_device_plugin ? "true" : "false" },
        var.install_slinky && !var.slinky_hostname_prefix_disabled ? { "oci.oraclecloud.com/slinky-hostname-prefix" = local.slinky_rdma_hostname_prefix } : {},
      )
      agent_config = {
        are_all_plugins_disabled = false
        is_management_disabled   = false
        is_monitoring_disabled   = false
        plugins_config = {
          "Bastion"                             = "DISABLED"
          "Block Volume Management"             = "DISABLED"
          "Compute HPC RDMA Authentication"     = "ENABLED"
          "Compute HPC RDMA Auto-Configuration" = "ENABLED"
          "Compute Instance Monitoring"         = "ENABLED"
          "Compute Instance Run Command"        = "ENABLED"
          "Compute RDMA GPU Monitoring"         = "ENABLED"
          "Custom Logs Monitoring"              = "ENABLED"
          "Management Agent"                    = "ENABLED"
          "Oracle Autonomous Linux"             = "DISABLED"
          "OS Management Service Agent"         = "DISABLED"
        }
      }
    },
    "oke-gmc" = {
      create                = local.create_workers && var.worker_gmc_enabled
      description           = "OKE self-managed GPU Memory Cluster"
      mode                  = "gpu-memory-cluster"
      placement_ads         = [substr(var.worker_gmc_ad, -1, 0)]
      shape                 = var.worker_gmc_shape
      gpu_memory_fabric_ids = local.worker_gmc_gpu_memory_fabric_ids
      gpu_memory_cluster_scale_config = {
        target_size         = var.worker_gmc_scale_target_size
        is_upsize_enabled   = var.worker_gmc_scale_is_upsize_enabled
        is_downsize_enabled = var.worker_gmc_scale_is_downsize_enabled
      }
      boot_volume_size               = var.worker_gmc_boot_volume_size
      boot_volume_vpus_per_gb        = var.worker_gmc_boot_volume_vpus_per_gb
      image_type                     = "custom"
      image_id                       = var.worker_gmc_image_id
      max_pods_per_node              = var.worker_gmc_max_pods_per_node
      kubernetes_version             = coalesce(var.worker_gmc_kubernetes_version, var.kubernetes_version)
      legacy_imds_endpoints_disabled = var.legacy_imds_endpoints_disabled
      cloud_init                     = [{ content_type = "text/cloud-config", content = yamlencode(local.cloud_init) }]
      node_metadata                  = local.node_metadata
      node_labels = merge(
        { "oci.oraclecloud.com/disable-gpu-device-plugin" = var.disable_gpu_device_plugin ? "true" : "false" },
        var.install_slinky && !var.slinky_hostname_prefix_disabled ? { "oci.oraclecloud.com/slinky-hostname-prefix" = local.slinky_gmc_hostname_prefix } : {},
      )
      agent_config = {
        are_all_plugins_disabled = false
        is_management_disabled   = false
        is_monitoring_disabled   = false
        plugins_config = {
          "Bastion"                             = "DISABLED"
          "Block Volume Management"             = "DISABLED"
          "Compute HPC RDMA Authentication"     = "ENABLED"
          "Compute HPC RDMA Auto-Configuration" = "ENABLED"
          "Compute Instance Monitoring"         = "ENABLED"
          "Compute Instance Run Command"        = "ENABLED"
          "Compute RDMA GPU Monitoring"         = "ENABLED"
          "Custom Logs Monitoring"              = "ENABLED"
          "Management Agent"                    = "ENABLED"
          "Oracle Autonomous Linux"             = "DISABLED"
          "OS Management Service Agent"         = "DISABLED"
        }
      }
    },
  }
}
