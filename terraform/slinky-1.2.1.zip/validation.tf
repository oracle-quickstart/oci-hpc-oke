# Copyright (c) 2025 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl

locals {
  invalid_desired_load_balancers = !var.create_public_subnets && var.preferred_kubernetes_services == "public"
  invalid_public_ep              = !var.create_public_subnets && var.control_plane_is_public
  invalid_bastion                = !var.create_public_subnets && var.create_bastion
  invalid_worker_rdma_image      = can(regex("(?i)oracle.*linux", one(data.oci_core_image.worker_rdma[*].display_name)))
  invalid_grace_blackwell_shape  = contains(["BM.GPU.GB200.4", "BM.GPU.GB200-v2.4", "BM.GPU.GB200-v3.4", "BM.GPU.GB300.4"], var.worker_rdma_shape)
  invalid_bastion_custom_image = var.create_bastion && local.bastion_image_type == "custom" && (
    var.bastion_image_use_uri ? trimspace(coalesce(var.bastion_image_custom_uri, "none")) == "none" : trimspace(coalesce(var.bastion_image_id, "none")) == "none"
  )
  invalid_operator_custom_image = var.create_operator && local.operator_image_type == "custom" && (
    var.operator_image_use_uri ? trimspace(coalesce(var.operator_image_custom_uri, "none")) == "none" : trimspace(coalesce(var.operator_image_id, "none")) == "none"
  )
  allowed_image_uri_prefixes = ["http://", "https://"]
  image_uri_values = {
    bastion     = lower(trimspace(coalesce(var.bastion_image_custom_uri, "none")))
    operator    = lower(trimspace(coalesce(var.operator_image_custom_uri, "none")))
    worker_ops  = lower(trimspace(coalesce(var.worker_ops_image_custom_uri, "none")))
    worker_cpu  = lower(trimspace(coalesce(var.worker_cpu_image_custom_uri, "none")))
    worker_gpu  = lower(trimspace(coalesce(var.worker_gpu_image_custom_uri, "none")))
    worker_rdma = lower(trimspace(coalesce(var.worker_rdma_image_custom_uri, "none")))
  }
  invalid_image_uri = anytrue([
    var.bastion_image_use_uri && !anytrue([for prefix in local.allowed_image_uri_prefixes : startswith(local.image_uri_values.bastion, prefix)]),
    var.operator_image_use_uri && !anytrue([for prefix in local.allowed_image_uri_prefixes : startswith(local.image_uri_values.operator, prefix)]),
    var.worker_ops_image_use_uri && !anytrue([for prefix in local.allowed_image_uri_prefixes : startswith(local.image_uri_values.worker_ops, prefix)]),
    var.worker_cpu_image_use_uri && !anytrue([for prefix in local.allowed_image_uri_prefixes : startswith(local.image_uri_values.worker_cpu, prefix)]),
    var.worker_gpu_image_use_uri && !anytrue([for prefix in local.allowed_image_uri_prefixes : startswith(local.image_uri_values.worker_gpu, prefix)]),
    var.worker_rdma_image_use_uri && !anytrue([for prefix in local.allowed_image_uri_prefixes : startswith(local.image_uri_values.worker_rdma, prefix)]),
  ])

  # Pods subnet capacity validation
  pods_required_ops  = var.worker_ops_pool_size * local.worker_ops_max_pods_per_node
  pods_required_cpu  = var.worker_cpu_enabled ? var.worker_cpu_pool_size * local.worker_cpu_max_pods_per_node : 0
  pods_required_gpu  = var.worker_gpu_enabled ? var.worker_gpu_pool_size * var.worker_gpu_max_pods_per_node : 0
  pods_required_rdma = var.worker_rdma_enabled ? var.worker_rdma_pool_size * var.worker_rdma_max_pods_per_node : 0
  pods_required_gmc  = var.worker_gmc_enabled ? length(local.worker_gmc_gpu_memory_fabric_ids) * var.worker_gmc_scale_target_size * var.worker_gmc_max_pods_per_node : 0
  total_pods_required = (
    local.pods_required_ops +
    local.pods_required_cpu +
    local.pods_required_gpu +
    local.pods_required_rdma +
    local.pods_required_gmc
  )

  # Calculate pods subnet capacity (IPs available minus 3 reserved IPs)
  vcn_prefix_length     = tonumber(split("/", var.vcn_cidrs)[1])
  pods_subnet_prefix    = var.pods_sn_cidr != null ? tonumber(split("/", var.pods_sn_cidr)[1]) : local.vcn_prefix_length + 1
  pods_subnet_capacity  = pow(2, 32 - local.pods_subnet_prefix) - 3
  is_vcn_native_cni     = contains(["npn", "VCN-Native Pod Networking"], var.cni_type)
  invalid_pods_capacity = local.is_vcn_native_cni && local.total_pods_required > local.pods_subnet_capacity

  # FSS PV cannot be created when all deploy paths are inactive (private endpoint, no operator, no ORM)
  fss_pv_unreachable = alltrue([
    local.create_fss_effective,
    !local.deploy_from_local,
    !local.deploy_from_orm,
    !local.deploy_from_operator,
  ])

  invalid_slinky_deploy_path = alltrue([
    var.install_slinky,
    !local.slinky_deploy_from_operator,
  ])
  invalid_slinky_cpu_workers = alltrue([
    var.install_slinky,
    var.slinky_cpu_worker_enabled,
    !var.worker_cpu_enabled,
  ])
  invalid_slinky_virtual_functions = alltrue([
    var.install_slinky,
    var.worker_rdma_enabled,
    local.slinky_rdma_network_mode_effective == "virtualFunctions",
    anytrue([
      !contains(keys(local.slinky_shape_rdma_vf_count), var.worker_rdma_shape),
      trimspace(coalesce(var.slinky_worker_rdma_network, "")) == "",
      trimspace(coalesce(var.slinky_worker_rdma_resource, "")) == "",
      local.slinky_rdma_vfs_per_node <= 0,
    ]),
  ])
  # An explicit VF request must not exceed what the chosen shape's SR-IOV policy
  # advertises, or worker pods stay unschedulable.
  invalid_slinky_rdma_vfs_per_node = alltrue([
    var.install_slinky,
    var.worker_rdma_enabled,
    local.slinky_rdma_network_mode_effective == "virtualFunctions",
    var.slinky_worker_rdma_vfs_per_node != null,
    contains(keys(local.slinky_shape_rdma_vf_count), var.worker_rdma_shape),
    coalesce(var.slinky_worker_rdma_vfs_per_node, 0) > lookup(local.slinky_shape_rdma_vf_count, var.worker_rdma_shape, 0),
  ])
  slinky_expected_accelerator_nodeset_count = (
    (var.worker_gpu_enabled ? 1 : 0) +
    (var.worker_rdma_enabled ? 1 : 0) +
    (var.worker_gmc_enabled ? length(local.worker_gmc_gpu_memory_fabric_ids) : 0)
  )
  slinky_enabled_nodeset_names = concat(
    sort(keys(local.slinky_worker_nodesets)),
    local.slinky_cpu_nodeset_enabled ? [var.slinky_cpu_nodeset_name] : [],
  )
  slinky_enabled_partition_names = concat(
    ["all"],
    local.slinky_enabled_nodeset_names,
    local.slinky_gmc_aggregate_partition_enabled ? [local.slinky_gmc_aggregate_partition_name] : [],
  )
  invalid_slinky_nodeset_name_collision = alltrue([
    var.install_slinky,
    anytrue([
      length(local.slinky_worker_nodesets) != local.slinky_expected_accelerator_nodeset_count,
      local.slinky_cpu_nodeset_enabled && contains(keys(local.slinky_worker_nodesets), var.slinky_cpu_nodeset_name),
      local.slinky_gmc_aggregate_partition_enabled && contains(local.slinky_enabled_nodeset_names, local.slinky_gmc_aggregate_partition_name),
    ]),
  ])
  invalid_slinky_nodeset_names = alltrue([
    var.install_slinky,
    anytrue([
      for name in local.slinky_enabled_nodeset_names :
      length(name) > 50 || !can(regex("^[a-z0-9]([-a-z0-9]*[a-z0-9])?$", name))
    ]),
  ])
  invalid_slinky_gmc_resource_names = alltrue([
    var.install_slinky,
    anytrue([for name in keys(local.slinky_gmc_worker_nodesets) : length(name) > 43]),
  ])
  invalid_slinky_default_partition = alltrue([
    var.install_slinky,
    var.slinky_install_slurm_cluster,
    anytrue([
      var.slinky_default_partition != "auto" && !contains(local.slinky_enabled_partition_names, local.slinky_default_partition_name),
      var.slinky_default_partition == "auto" && length(local.slinky_enabled_nodeset_names) > 0 && !contains(local.slinky_enabled_partition_names, local.slinky_default_partition_name),
    ]),
  ])
  invalid_slinky_mixed_gpu_vendors = alltrue([
    var.install_slinky,
    length(local.slinky_enabled_worker_vendors) > 1,
  ])
  invalid_slinky_gmc_fabrics = alltrue([
    var.install_slinky,
    var.worker_gmc_enabled,
    length(local.worker_gmc_gpu_memory_fabric_ids) == 0,
  ])
  invalid_slinky_gmc_dra = alltrue([
    var.install_slinky,
    var.worker_gmc_enabled,
    !var.install_nvidia_dra_driver,
  ])
  invalid_slinky_gmc_labeler = alltrue([
    var.install_slinky,
    var.worker_gmc_enabled,
    anytrue([!var.install_oci_hpc_oke_utils, !var.install_rdma_labeler]),
  ])
  invalid_slinky_openldap_topology = alltrue([
    var.install_slinky,
    var.slinky_identity_enabled,
    var.slinky_openldap_primary_replicas != 1,
  ])
  invalid_slinky_login_without_identity = alltrue([
    var.install_slinky,
    var.slinky_install_slurm_cluster,
    var.slinky_login_enabled,
    !var.slinky_identity_enabled,
  ])
  invalid_slinky_worker_identity_without_ssh = alltrue([
    var.install_slinky,
    var.slinky_install_slurm_cluster,
    var.slinky_identity_enabled,
    !var.slinky_worker_ssh_enabled,
  ])
  invalid_slinky_annotator_without_utils = alltrue([
    local.slinky_hostname_annotator_enabled,
    !var.install_oci_hpc_oke_utils,
  ])
  # The generated Slurm values are chart 1.2-only: workers rely on the
  # hostname-override annotation instead of -N naming, and the chart 1.1
  # built-in slinky NodeSet is no longer overridden off.
  invalid_slinky_chart_below_1_2 = alltrue([
    var.install_slinky,
    anytrue([
      for v in [local.slinky_operator_chart_version, local.slinky_slurm_chart_version] :
      try(
        tonumber(split(".", v)[0]) < 1 ||
        (tonumber(split(".", v)[0]) == 1 && tonumber(split(".", v)[1]) < 2),
        false
      )
    ]),
  ])

  # Check if the ssh_public_key has comment
  ssh_public_key_has_comment = can(regex("\\S+\\s+\\S+\\s+\\S+\\s?", var.ssh_public_key))

  invalid_gpu_operator_without_nfd     = var.deploy_nvidia_gpu_operator && !var.deploy_node_feature_discovery
  invalid_network_operator_without_nfd = var.deploy_nvidia_network_operator && !var.deploy_node_feature_discovery
  invalid_nvidia_dra_without_nfd       = var.install_nvidia_dra_driver && var.worker_gmc_enabled && !var.deploy_node_feature_discovery
}

data "oci_core_image" "worker_rdma" {
  count    = coalesce(var.worker_rdma_image_custom_id, var.worker_rdma_image_platform_id, "none") != "none" ? 1 : 0
  image_id = coalesce(var.worker_rdma_image_custom_id, var.worker_rdma_image_platform_id, "none")
}

resource "null_resource" "validate_bastion_networking" {
  count = local.invalid_bastion ? 1 : 0

  provisioner "local-exec" {
    command = "echo 'Error: Bastion requires public subnets to be created' && exit 1"
  }

  lifecycle {
    precondition {
      condition     = !local.invalid_bastion
      error_message = "Creating a bastion requires public subnets. Please set `create_public_subnets=true` or set `create_bastion=false`."
    }
  }
}

resource "null_resource" "validate_cluster_services" {
  count = local.invalid_desired_load_balancers ? 1 : 0

  provisioner "local-exec" {
    command = "echo 'Error: Public Kubernetes services require public subnets to be created' && exit 1"
  }

  lifecycle {
    precondition {
      condition     = !local.invalid_desired_load_balancers
      error_message = "Public Kubernetes services require public subnets. Please set `create_public_subnets=true` or change `preferred_kubernetes_services` to a different value."
    }
  }
}

resource "null_resource" "validate_cluster_endpoint" {
  count = local.invalid_public_ep ? 1 : 0

  provisioner "local-exec" {
    command = "echo 'Error: Public cluster endpoint requires public subnets to be created' && exit 1"
  }

  lifecycle {
    precondition {
      condition     = !local.invalid_public_ep
      error_message = "A public cluster endpoint requires public subnets. Please set `create_public_subnets=true` or change `control_plane_is_public=false`."
    }
  }
}

resource "null_resource" "validate_worker_rdma_image" {
  count = coalesce(var.worker_rdma_image_custom_id, var.worker_rdma_image_platform_id, "none") != "none" ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_worker_rdma_image
      error_message = "GPU & RDMA worker pools only support Ubuntu images. The selected image '${one(data.oci_core_image.worker_rdma[*].display_name)}' is an Oracle Linux image. Please choose an Ubuntu-based custom image."
    }
  }
}

resource "null_resource" "validate_image_uri" {
  count = anytrue([var.bastion_image_use_uri, var.operator_image_use_uri, var.worker_ops_image_use_uri, var.worker_cpu_image_use_uri, var.worker_gpu_image_use_uri, var.worker_rdma_image_use_uri]) ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_image_uri
      error_message = "Error: Invalid image URI detected. Image import URIs must start with http:// or https://."
    }
  }
}

resource "null_resource" "validate_bastion_image_selection" {
  count = local.invalid_bastion_custom_image ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_bastion_custom_image
      error_message = "When bastion_image_type is custom, provide either bastion_image_id or enable bastion_image_use_uri with bastion_image_custom_uri."
    }
  }
}

resource "null_resource" "validate_operator_image_selection" {
  count = local.invalid_operator_custom_image ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_operator_custom_image
      error_message = "When operator_image_type is custom, provide either operator_image_id or enable operator_image_use_uri with operator_image_custom_uri."
    }
  }
}

resource "null_resource" "validate_grace_blackwell_shape" {
  count = local.invalid_grace_blackwell_shape ? 1 : 0

  provisioner "local-exec" {
    command = "echo 'Error: GB200 shapes require a different deployment process' && exit 1"
  }

  lifecycle {
    precondition {
      condition     = !local.invalid_grace_blackwell_shape
      error_message = "GB200/GB300 shapes (BM.GPU.GB200.4, BM.GPU.GB200-v2.4, BM.GPU.GB200-v3.4, BM.GPU.GB300.4) require a different deployment process. Please deploy the OKE cluster without the GPU & RDMA worker pool, then follow the GB200-specific instructions at: https://github.com/oracle-quickstart/oci-hpc-oke/tree/gb200"
    }
  }
}

resource "null_resource" "validate_pods_capacity" {
  count = local.invalid_pods_capacity ? 1 : 0

  provisioner "local-exec" {
    command = "echo 'Error: Total required pod IPs exceeds pods subnet capacity' && exit 1"
  }

  lifecycle {
    precondition {
      condition     = !local.invalid_pods_capacity
      error_message = <<-EOT
        Total required pod IPs (${local.total_pods_required}) exceeds pods subnet capacity (${local.pods_subnet_capacity}).
        Breakdown:
          - oke-system: ${local.pods_required_ops} (${var.worker_ops_pool_size} nodes × ${var.worker_ops_max_pods_per_node} pods)
          - oke-cpu: ${local.pods_required_cpu} (${var.worker_cpu_enabled ? var.worker_cpu_pool_size : 0} nodes × ${var.worker_cpu_max_pods_per_node} pods)
          - oke-gpu: ${local.pods_required_gpu} (${var.worker_gpu_enabled ? var.worker_gpu_pool_size : 0} nodes × ${var.worker_gpu_max_pods_per_node} pods)
          - oke-rdma: ${local.pods_required_rdma} (${var.worker_rdma_enabled ? var.worker_rdma_pool_size : 0} nodes × ${var.worker_rdma_max_pods_per_node} pods)
          - oke-gmc: ${local.pods_required_gmc} (${var.worker_gmc_enabled ? length(local.worker_gmc_gpu_memory_fabric_ids) * var.worker_gmc_scale_target_size : 0} nodes × ${var.worker_gmc_max_pods_per_node} pods)
        Consider increasing the pods subnet size or reducing max_pods_per_node/pool_size values.
      EOT
    }
  }
}

resource "null_resource" "warn_fss_pv_unreachable" {
  count = local.fss_pv_unreachable ? 1 : 0

  provisioner "local-exec" {
    command = "echo 'Warning: create_fss=true but the Kubernetes API server is unreachable from this context (private endpoint, no operator, no ORM private endpoint). The FSS PersistentVolume will not be created. To resolve, enable the operator (create_operator=true with create_bastion=true), use a public control plane endpoint, or enable deploy_to_oke_from_orm=true when deploying via ORM.'"
  }

  lifecycle {
    precondition {
      condition     = !local.fss_pv_unreachable
      error_message = "create_fss=true but the Kubernetes API server is unreachable from this context (private endpoint, no operator, no ORM private endpoint). The FSS PersistentVolume will not be created. To resolve: enable the operator (create_operator=true with create_bastion=true), use a public control plane endpoint, or enable deploy_to_oke_from_orm=true when deploying via ORM."
    }
  }
}

resource "null_resource" "validate_slinky_deploy_path" {
  count = local.invalid_slinky_deploy_path ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_deploy_path
      error_message = "install_slinky=true currently deploys the full Slurm suite from the operator host. Please set create_bastion=true, create_operator=true, and deploy_to_oke_from_orm=false."
    }
  }
}

resource "null_resource" "validate_slinky_cpu_workers" {
  count = local.invalid_slinky_cpu_workers ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_cpu_workers
      error_message = "slinky_cpu_worker_enabled=true requires worker_cpu_enabled=true so the CPU worker pool exists."
    }
  }
}

resource "null_resource" "validate_slinky_virtual_functions" {
  count = local.invalid_slinky_virtual_functions ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_virtual_functions
      error_message = "slinky_worker_network_mode=virtualFunctions requires worker_rdma_enabled=true, a VF-capable RDMA worker shape, non-empty slinky_worker_rdma_resource and slinky_worker_rdma_network, and slinky_worker_rdma_vfs_per_node > 0."
    }
  }
}

resource "null_resource" "validate_slinky_rdma_vfs_per_node" {
  count = local.invalid_slinky_rdma_vfs_per_node ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_rdma_vfs_per_node
      error_message = "slinky_worker_rdma_vfs_per_node (${coalesce(var.slinky_worker_rdma_vfs_per_node, 0)}) exceeds the SR-IOV VFs advertised for ${var.worker_rdma_shape} (${lookup(local.slinky_shape_rdma_vf_count, var.worker_rdma_shape, 0)}). Lower it to that value or less, or leave it null to auto-derive."
    }
  }
}

resource "null_resource" "validate_slinky_nodesets" {
  count = anytrue([
    local.invalid_slinky_nodeset_name_collision,
    local.invalid_slinky_nodeset_names,
    local.invalid_slinky_gmc_resource_names,
    local.invalid_slinky_default_partition,
    local.invalid_slinky_mixed_gpu_vendors,
    local.invalid_slinky_gmc_fabrics,
    local.invalid_slinky_gmc_dra,
    local.invalid_slinky_gmc_labeler,
  ]) ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_nodeset_name_collision
      error_message = "Every enabled Slurm worker pool and GPU memory fabric must have a unique NodeSet name. Change slinky_nodeset_name, slinky_rdma_nodeset_name, slinky_gmc_nodeset_name, or slinky_cpu_nodeset_name."
    }
    precondition {
      condition     = !local.invalid_slinky_nodeset_names
      error_message = "Slurm NodeSet names must be valid lowercase DNS labels no longer than 50 characters."
    }
    precondition {
      condition     = !local.invalid_slinky_gmc_resource_names
      error_message = "Generated GMC NodeSet names must be no longer than 43 characters so their IMEX ComputeDomain names fit the Kubernetes 63-character limit. Shorten slinky_gmc_nodeset_name."
    }
    precondition {
      condition     = !local.invalid_slinky_default_partition
      error_message = "slinky_default_partition must select an enabled Slurm partition using auto, gpu, rdma, gmc, cpu, all, or an exact generated partition name."
    }
    precondition {
      condition     = !local.invalid_slinky_mixed_gpu_vendors
      error_message = "A Slurm cluster cannot currently mix AMD and NVIDIA accelerator NodeSets because gres.conf has one global AutoDetect backend. Use pools from one GPU vendor."
    }
    precondition {
      condition     = !local.invalid_slinky_gmc_fabrics
      error_message = "Slurm GPU Memory Cluster workers require at least one worker_gmc_gpu_memory_fabric_ids OCID."
    }
    precondition {
      condition     = !local.invalid_slinky_gmc_dra
      error_message = "Slurm GPU Memory Cluster workers require install_nvidia_dra_driver=true for their IMEX ComputeDomain claims."
    }
    precondition {
      condition     = !local.invalid_slinky_gmc_labeler
      error_message = "Slurm GPU Memory Cluster workers require install_oci_hpc_oke_utils=true and install_rdma_labeler=true so each NodeSet can select its GPU memory fabric."
    }
  }
}

resource "null_resource" "validate_slinky_openldap_topology" {
  count = local.invalid_slinky_openldap_topology ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_openldap_topology
      error_message = "The bundled HA OpenLDAP topology supports exactly one writable primary plus read replicas. Keep slinky_openldap_primary_replicas=1."
    }
  }
}

resource "null_resource" "validate_slinky_login_identity" {
  count = local.invalid_slinky_login_without_identity ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_login_without_identity
      error_message = "slinky_login_enabled=true requires slinky_identity_enabled=true. Otherwise the Slinky slurm chart configures the LoginSet with its placeholder SSSD configuration. Enable managed identity or disable the Slurm login service."
    }
  }
}

resource "null_resource" "validate_slinky_worker_identity" {
  count = local.invalid_slinky_worker_identity_without_ssh ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_worker_identity_without_ssh
      error_message = "slinky_worker_ssh_enabled=false is incompatible with slinky_identity_enabled=true because the Slinky slurm chart couples worker SSSD configuration to SSH. Keep worker SSH enabled or disable managed identity."
    }
  }
}

resource "null_resource" "validate_slinky_hostname_annotator" {
  count = local.invalid_slinky_annotator_without_utils ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_annotator_without_utils
      error_message = "install_slinky=true with hostname_override=false requires install_oci_hpc_oke_utils=true: the oci-hpc-oke-utils annotator sets the node hostname-override annotation that keeps Slurm node names clean when Kubernetes node names are IP addresses. Enable oci-hpc-oke-utils or set hostname_override=true."
    }
  }
}

resource "null_resource" "validate_slinky_chart_version" {
  count = local.invalid_slinky_chart_below_1_2 ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_slinky_chart_below_1_2
      error_message = "slinky_operator_chart_version and slinky_slurm_chart_version must be 1.2.0 or later: the stack generates 1.2-only Slurm values (worker names come from the slurm-operator 1.2 hostname-override annotation instead of -N, and the chart 1.1 built-in slinky NodeSet is not overridden off). Use auto or pin 1.2 or later."
    }
  }
}

resource "null_resource" "ssh_public_key_should_have_comment" {
  count = alltrue([local.any_deployments_via_operator, var.ssh_public_key != null]) ? 1 : 0

  lifecycle {
    precondition {
      condition     = local.ssh_public_key_has_comment
      error_message = "Error: SSH public key should have a comment. Please ensure the SSH public key has a comment."
    }
  }
}

resource "null_resource" "validate_gpu_operator_requires_nfd" {
  count = local.invalid_gpu_operator_without_nfd ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_gpu_operator_without_nfd
      error_message = "NVIDIA GPU Operator addon requires Node Feature Discovery. Please set `deploy_node_feature_discovery=true` or set `deploy_nvidia_gpu_operator=false`."
    }
  }
}

resource "null_resource" "validate_network_operator_requires_nfd" {
  count = local.invalid_network_operator_without_nfd ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_network_operator_without_nfd
      error_message = "NVIDIA Network Operator addon requires Node Feature Discovery. Please set `deploy_node_feature_discovery=true` or set `deploy_nvidia_network_operator=false`."
    }
  }
}

resource "null_resource" "validate_nvidia_dra_requires_nfd" {
  count = local.invalid_nvidia_dra_without_nfd ? 1 : 0

  lifecycle {
    precondition {
      condition     = !local.invalid_nvidia_dra_without_nfd
      error_message = "NVIDIA DRA driver requires Node Feature Discovery for GPU node selection. Please set `deploy_node_feature_discovery=true` or set `install_nvidia_dra_driver=false`."
    }
  }
}
